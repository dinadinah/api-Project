Hello,

Thank for downloading FUJIMARU. You can use the font for personal use only, if you want the full commercial license and more extended licenses, you can buy the  font here 
————————————————————————————————————————————————————————————————————————
https://creativemarket.com/nurrehmettt/2646145-Fujimaru-Ninjas-Brush-Font
————————————————————————————————————————————————————————————————————————
If there is a problem, question, or anything about my fonts, please sent an email to

nurrehmet2@gmail.com

How to Enable OpenType Features in Word, Photoshop and Illustrator

https://medialoot.com/blog/how-to-enable-opentype-features-in-word-photoshop-and-illustrator/

Regards,


Nurrehmet Studio